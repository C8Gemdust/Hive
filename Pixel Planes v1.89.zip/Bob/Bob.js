/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Bob extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("bob", "./Bob/costumes/bob.svg", {
        x: 90.5,
        y: 90.50000000000004,
      }),
      new Costume("bob2", "./Bob/costumes/bob2.svg", {
        x: 157.12919826652222,
        y: 171.29902491874324,
      }),
    ];

    this.sounds = [
      new Sound("cow3", "./Bob/sounds/cow3.wav"),
      new Sound(
        "Minecraft - Calming Game Music2",
        "./Bob/sounds/Minecraft - Calming Game Music2.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.BROADCAST, { name: "cow" }, this.whenIReceiveCow),
      new Trigger(Trigger.BROADCAST, { name: "cow" }, this.whenIReceiveCow2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "cow part 2" },
        this.whenIReceiveCowPart2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.clear();
    yield* this.startSound("Minecraft - Calming Game Music2");
    this.costume = "bob";
    this.visible = false;
    this.size = 20;
    this.goto(174, 12);
  }

  *whenIReceiveCow() {
    this.visible = true;
    yield* this.glide(0.5, 0, 0);
  }

  *whenIReceiveCow2() {
    while (!(this.size === 100)) {
      this.size += 5;
      yield;
    }
    this.broadcast("cow part 2");
    this.stopAllSounds();
  }

  *whenIReceiveCowPart2() {
    yield* this.wait(1);
    this.costumeNumber++;
    yield* this.wait(0.5);
    yield* this.playSoundUntilDone("cow3");
    yield* this.wait(1);
    this.costume = "bob";
    for (let i = 0; i < 10; i++) {
      this.size += 10;
      this.effects.ghost += 10;
      yield* this.wait(0.1);
      yield;
    }
    this.broadcast("End of intro");
  }
}
