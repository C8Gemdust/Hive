/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Sky", "./Stage/costumes/Sky.svg", {
        x: 273.00000000000006,
        y: 278.0000000000002,
      }),
    ];

    this.sounds = [
      new Sound("Game over", "./Stage/sounds/Game over.wav"),
      new Sound(
        "Kevin_MacLeod_-_Monkeys_Spinning_Monkeys",
        "./Stage/sounds/Kevin_MacLeod_-_Monkeys_Spinning_Monkeys.wav"
      ),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
    ];

    this.vars.speedX = 8.5;
    this.vars.Score = 24;
    this.vars.hp = 0;
    this.vars.pointsPerSecond = 1;
    this.vars.speed = 8.5;

    this.watchers.Score = new Watcher({
      label: "☁ Score",
      style: "normal",
      visible: true,
      value: () => this.vars.Score,
      x: 245,
      y: 175,
    });
    this.watchers.hp = new Watcher({
      label: "Hp",
      style: "normal",
      visible: true,
      value: () => this.vars.hp,
      x: 245,
      y: 145,
    });
    this.watchers.pointsPerSecond = new Watcher({
      label: "Points per second",
      style: "normal",
      visible: true,
      value: () => this.vars.pointsPerSecond,
      x: 245,
      y: 119,
    });
    this.watchers.speed = new Watcher({
      label: "Speed",
      style: "normal",
      visible: true,
      value: () => this.vars.speed,
      x: 242,
      y: -153,
    });
  }

  *whenGreenFlagClicked() {
    this.watchers.Score.visible = false;
    this.watchers.pointsPerSecond.visible = false;
    this.watchers.hp.visible = false;
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
    yield* this.playSoundUntilDone("Game over");
  }

  *whenIReceiveEndOfIntro() {
    this.watchers.Score.visible = true;
    this.watchers.pointsPerSecond.visible = true;
    this.watchers.hp.visible = true;
    while (true) {
      yield* this.playSoundUntilDone(
        "Kevin_MacLeod_-_Monkeys_Spinning_Monkeys"
      );
      yield;
    }
  }
}
