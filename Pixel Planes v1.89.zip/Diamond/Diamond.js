/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Diamond extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Blank", "./Diamond/costumes/Blank.svg", { x: 0, y: 0 }),
      new Costume("Diamond", "./Diamond/costumes/Diamond.png", {
        x: 28,
        y: 31,
      }),
    ];

    this.sounds = [new Sound("Diamond", "./Diamond/sounds/Diamond.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    while (!this.touching(this.sprites["Player"].andClones())) {
      yield;
    }
    yield* this.startSound("Diamond");
    this.stage.vars.pointsPerSecond += this.random(1, 3);
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      this.costume = "Blank";
      yield* this.wait(0.5);
      this.costume = "Diamond";
      yield* this.wait(0.5);
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *startAsClone3() {
    yield* this.wait(3);
    this.deleteThisClone();
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.costume = "Blank";
    while (true) {
      yield* this.wait(this.random(7, 12));
      this.createClone();
      yield;
    }
  }
}
