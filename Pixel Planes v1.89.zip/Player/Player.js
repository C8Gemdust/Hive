/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Player extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Player", "./Player/costumes/Player.png", { x: 86, y: 58 }),
    ];

    this.sounds = [
      new Sound("Falling", "./Player/sounds/Falling.wav"),
      new Sound("Explosion", "./Player/sounds/Explosion.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Lose Hp" },
        this.whenIReceiveLoseHp
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro2
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro3
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro4
      ),
    ];

    this.vars.speedY = 8.5;
  }

  *whenGreenFlagClicked() {
    this.stage.watchers.speed.visible = false;
    this.visible = false;
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
    this.direction += 30;
    yield* this.startSound("Falling");
    while (!(this.y === -206)) {
      this.y -= 10;
      yield;
    }
    this.visible = false;
    this.stopAllSounds();
    yield* this.startSound("Explosion");
  }

  *whenGreenFlagClicked2() {}

  *whenIReceiveLoseHp() {
    this.stage.vars.hp--;
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.direction = 90;
    this.stage.watchers.speed.visible = true;
    this.stage.vars.pointsPerSecond = 1;
    this.stage.vars.speed = 9.5;
    this.stage.vars.hp = 5;
    this.stage.vars.Score = 0;
    this.stage.vars.speedX = this.stage.vars.speed;
    this.vars.speedY = this.stage.vars.speed;
    this.goto(-195, -9);
    while (true) {
      if (this.keyPressed("up arrow") || this.keyPressed("w")) {
        this.y += this.toNumber(this.vars.speedY);
      }
      if (this.keyPressed("down arrow") || this.keyPressed("s")) {
        this.y += this.toNumber(this.vars.speedY) * -1;
      }
      if (this.keyPressed("right arrow") || this.keyPressed("d")) {
        this.x += this.toNumber(this.stage.vars.speedX);
      }
      if (this.keyPressed("left arrow") || this.keyPressed("a")) {
        this.x += this.toNumber(this.stage.vars.speedX) * -1;
      }
      yield;
    }
  }

  *whenIReceiveEndOfIntro2() {
    while (true) {
      yield* this.wait(1);
      this.stage.vars.Score += this.toNumber(this.stage.vars.pointsPerSecond);
      yield;
    }
  }

  *whenIReceiveEndOfIntro3() {
    while (true) {
      if (this.compare(this.stage.vars.hp, 1) < 0) {
        this.broadcast("Game Over");
        this.stage.vars.hp = 0;
      }
      yield;
    }
  }

  *whenIReceiveEndOfIntro4() {
    while (true) {
      this.stage.vars.speedX = this.stage.vars.speed;
      this.vars.speedY = this.stage.vars.speed;
      yield;
    }
  }
}
