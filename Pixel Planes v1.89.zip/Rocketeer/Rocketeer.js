/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Rocketeer extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Rocketeer", "./Rocketeer/costumes/Rocketeer.png", {
        x: 90,
        y: 46,
      }),
      new Costume("Blank", "./Rocketeer/costumes/Blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.costume = "Rocketeer";
    this.goto(198, this.random(-170, 170));
    while (!this.touching("edge")) {
      this.x -= 20;
      yield;
    }
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      if (this.touching(this.sprites["Player"].andClones())) {
        this.stage.vars.speed--;
        this.stage.vars.hp--;
        this.deleteThisClone();
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      null;
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.goto(197, -28);
    while (true) {
      yield* this.wait(this.random(4, 6));
      this.createClone();
      yield;
    }
  }

  *whenIReceiveEndOfIntro2() {
    this.costume = "Blank";
  }
}
