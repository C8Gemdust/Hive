/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class IntroBackdrop extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./IntroBackdrop/costumes/costume1.svg", {
        x: 381.927,
        y: 213.87912,
      }),
    ];

    this.sounds = [new Sound("pop", "./IntroBackdrop/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
    ];
  }

  *whenGreenFlagClicked() {
    this.effects.ghost = 0;
    this.goto(36, 28);
    while (!(this.compare(this.x, -121) < 0)) {
      this.move(-2);
      yield* this.wait(0.1);
      yield;
    }
    this.broadcast("cow");
    while (true) {
      this.effects.ghost += 5;
      yield;
    }
  }
}
