/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Cloud extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Cloud", "./Cloud/costumes/Cloud.svg", {
        x: 26.608552631578988,
        y: 13.304276315789451,
      }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.visible = true;
    this.goto(178, this.random(-147, 147));
    while (!this.touching("edge")) {
      this.move(-5);
      yield;
    }
    this.deleteThisClone();
  }

  *whenGreenFlagClicked2() {}

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.moveBehind();
    while (true) {
      this.createClone();
      yield* this.wait(2);
      yield;
    }
  }

  *whenIReceiveEndOfIntro2() {
    this.goto(178, this.random(-147, 147));
    while (true) {
      while (!this.touching("edge")) {
        this.move(-5);
        yield;
      }
      this.goto(178, this.random(-147, 147));
      yield;
    }
  }
}
