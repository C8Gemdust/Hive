/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Enemy extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Enemy", "./Enemy/costumes/Enemy.svg", {
        x: 42.125806451612846,
        y: 26.077880184331747,
      }),
      new Costume("Blank", "./Enemy/costumes/Blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro2
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.costume = "Enemy";
    this.goto(198, this.random(-170, 170));
    while (!this.touching("edge")) {
      this.x -= 10;
      yield;
    }
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      if (this.touching(this.sprites["Player"].andClones())) {
        this.broadcast("Lose Hp");
        this.deleteThisClone();
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      null;
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.goto(197, -28);
    while (true) {
      this.createClone();
      yield* this.wait(0.6);
      yield;
    }
  }

  *whenIReceiveEndOfIntro2() {
    this.costume = "Blank";
  }
}
