/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Coin extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Coin", "./Coin/costumes/Coin.png", { x: 32, y: 30 }),
      new Costume("Blank", "./Coin/costumes/Blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("Coin sound", "./Coin/sounds/Coin sound.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    while (!this.touching(this.sprites["Player"].andClones())) {
      yield;
    }
    yield* this.startSound("Coin sound");
    this.stage.vars.Score += this.random(1, 3);
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      this.costume = "Blank";
      yield* this.wait(0.5);
      this.costume = "Coin";
      yield* this.wait(0.5);
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.costume = "Blank";
    while (true) {
      yield* this.wait(this.random(2, 3));
      this.createClone();
      yield;
    }
  }
}
