/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Pizza extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Pizza", "./Pizza/costumes/Pizza.png", { x: 28, y: 28 }),
      new Costume("Blank", "./Pizza/costumes/Blank.svg", { x: 0, y: 0 }),
    ];

    this.sounds = [new Sound("om-nom-nom", "./Pizza/sounds/om-nom-nom.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    while (!this.touching(this.sprites["Player"].andClones())) {
      yield;
    }
    yield* this.startSound("om-nom-nom");
    this.stage.vars.hp += this.random(2, 3);
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      this.costume = "Blank";
      yield* this.wait(0.5);
      this.costume = "Pizza";
      yield* this.wait(0.5);
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *startAsClone3() {
    yield* this.wait(5);
    this.deleteThisClone();
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.costume = "Blank";
    while (true) {
      yield* this.wait(this.random(7, 10));
      this.createClone();
      yield;
    }
  }
}
