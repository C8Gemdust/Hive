/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class JetEngine extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Blank", "./JetEngine/costumes/Blank.svg", { x: 0, y: 0 }),
      new Costume("Jet engine", "./JetEngine/costumes/Jet engine.png", {
        x: 100,
        y: 100,
      }),
    ];

    this.sounds = [
      new Sound("Vroom sound", "./JetEngine/sounds/Vroom sound.wav"),
      new Sound("Meow", "./JetEngine/sounds/Meow.wav"),
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.CLONE_START, this.startAsClone),
      new Trigger(Trigger.CLONE_START, this.startAsClone2),
      new Trigger(
        Trigger.BROADCAST,
        { name: "Game Over" },
        this.whenIReceiveGameOver
      ),
      new Trigger(Trigger.CLONE_START, this.startAsClone3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "End of intro" },
        this.whenIReceiveEndOfIntro
      ),
    ];
  }

  *whenGreenFlagClicked() {
    this.visible = false;
  }

  *startAsClone() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    while (!this.touching(this.sprites["Player"].andClones())) {
      yield;
    }
    yield* this.startSound("Vroom sound");
    this.stage.vars.speed += this.random(1, 2);
    this.deleteThisClone();
  }

  *startAsClone2() {
    while (true) {
      this.costume = "Blank";
      yield* this.wait(0.5);
      this.costume = "Jet engine";
      yield* this.wait(0.5);
      yield;
    }
  }

  *whenIReceiveGameOver() {
    /* TODO: Implement stop other scripts in sprite */ null;
  }

  *startAsClone3() {
    yield* this.wait(5);
    this.deleteThisClone();
  }

  *whenIReceiveEndOfIntro() {
    this.visible = true;
    this.costume = "Blank";
    while (true) {
      yield* this.wait(this.random(5, 10));
      this.createClone();
      yield;
    }
  }
}
