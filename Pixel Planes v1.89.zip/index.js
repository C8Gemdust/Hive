import {
  Project,
  Sprite,
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Player from "./Player/Player.js";
import Cloud from "./Cloud/Cloud.js";
import Enemy from "./Enemy/Enemy.js";
import Coin from "./Coin/Coin.js";
import Pizza from "./Pizza/Pizza.js";
import Rocketeer from "./Rocketeer/Rocketeer.js";
import Diamond from "./Diamond/Diamond.js";
import IntroBackdrop from "./IntroBackdrop/IntroBackdrop.js";
import Bob from "./Bob/Bob.js";
import Thumbnail from "./Thumbnail/Thumbnail.js";
import JetEngine from "./JetEngine/JetEngine.js";
import Blank from "./Blank/Blank.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Player: new Player({
    x: -147.5,
    y: -206,
    direction: 120,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 90,
    visible: false,
    layerOrder: 8,
  }),
  Cloud: new Cloud({
    x: 63,
    y: -138,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 200,
    visible: true,
    layerOrder: 1,
  }),
  Enemy: new Enemy({
    x: 197,
    y: -28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 3,
  }),
  Coin: new Coin({
    x: -91,
    y: -11,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 7,
  }),
  Pizza: new Pizza({
    x: -9.736335752239533,
    y: 16.48080808089345,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 6,
  }),
  Rocketeer: new Rocketeer({
    x: 197,
    y: -28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 2,
    size: 100,
    visible: true,
    layerOrder: 2,
  }),
  Diamond: new Diamond({
    x: -5.76153018945762,
    y: 44.66326679131644,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 5,
  }),
  IntroBackdrop: new IntroBackdrop({
    x: -122,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 9,
  }),
  Bob: new Bob({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 200,
    visible: true,
    layerOrder: 10,
  }),
  Thumbnail: new Thumbnail({
    x: 0,
    y: 0,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 12,
  }),
  JetEngine: new JetEngine({
    x: 69.71450237679164,
    y: -43.45620994451639,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 4,
  }),
  Blank: new Blank({
    x: 36,
    y: 28,
    direction: 90,
    rotationStyle: Sprite.RotationStyle.ALL_AROUND,
    costumeNumber: 1,
    size: 100,
    visible: true,
    layerOrder: 11,
  }),
};

const project = new Project(stage, sprites, {
  frameRate: 30, // Set to 60 to make your project run faster
});
export default project;
